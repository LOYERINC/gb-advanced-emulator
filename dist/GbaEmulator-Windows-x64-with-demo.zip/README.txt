GBA Emulator — Windows x64

Extract the ZIP and open GbaEmulator.exe. Choose gradient_demo.gba with Open ROM…,
then click Run. Python is not required; this build is for 64-bit Windows 10 or newer.

Controls: arrows = D-pad; Z/X = A/B; A/S = L/R; Enter/Backspace = Start/Select.

This early emulator supports a subset of GBA hardware. Some games may pause on
unsupported instructions. No games or Nintendo BIOS are included. Use ROMs you
have the right to use. Saves are written beside the selected ROM.
